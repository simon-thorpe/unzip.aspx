jQuery(function(){
	setTimeout(function(){
		$('img').fadeIn('slow');
	},3000);
});